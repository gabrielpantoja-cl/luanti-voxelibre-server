 _______  __   __  _______  _______  _______ 
|       ||  | |  ||       ||       ||       |
|       ||  |_|  ||    ___||  _____||  _____|
|       ||       ||   |___ | |_____ | |_____ 
|      _||       ||    ___||_____  ||_____  |
|     |_ |   _   ||   |___  _____| | _____| |
|_______||__| |__||_______||_______||_______|

BY:             bas080
DESCRIPTION:    Play chess in Minetest
VERSION:        1.0
LICENCE:        WTFPL
FORUM:          http://minetest.net/forum/viewtopic.php?id=2784

Changelog
1.0
* Added node ownership by punshing king
* Changed craft for chess spawner

0.5
* Chessboard with numbered and lettered border
* Added craft for chess spawner


0.2
* Tonyka contributed nodes for chess pieces
* Improved chess spawner with chess pieces

0.1
* Rubenwardy made code layout
* Chess spawner

Licence
WTFPL
