# chess
minetest chess pieces
