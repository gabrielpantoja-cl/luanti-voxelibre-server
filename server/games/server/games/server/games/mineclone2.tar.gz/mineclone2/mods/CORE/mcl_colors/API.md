# mcl_colors
Mod providing global table containing legacy Minecraft colors to be used in mods.

## mcl_colors.*
Colors by upper name, in hex value.

## mcl_colors.background.*
Background colors by upper name, in hex value.
