# `mcl_moon` API
This API has one function:

## `mcl_moon.get_moon_phase()`

Returns current moon phase (0-7).

* 0 = Full Moon
* 1 = Waning Gibbous
* 2 = Last Quarter
* 3 = Waning Crescent
* 4 = New Moon
* 5 = Waxing Crescent
* 6 = First Quarter
* 7 = Waxing Gibbous 
