===ITEM_DROP MOD for Luanti===
by PilzAdam

Introduction:
This mod adds Minecraft like drop/pick up of items to Luanti.

This mod has been forked from item_drop in the VoxBox game.

License:
Sourcecode: WTFPL (see below)
Sound: WTFPL (see below)

See also:
https://www.luanti.org/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.

---------

Alterations and contributions are released under GNU GPLv3 after 11/11/2022 and for contributors:

AncientMariner/ancientmarinerdev
