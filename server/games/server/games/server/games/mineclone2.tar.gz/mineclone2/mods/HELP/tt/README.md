# Extended Tooltip (`tt`)
This mod extends the tooltip of items to add more informative texts.

The mod itself does nothing and is meant to be integrated into
games to use the API to define custom tooltips (see `API.md`).

## License
MIT License.
