mcl_bamboo
=========

This mod adds working, familiar bamboo nodes to your VoxeLibre world.

Code: Michieal. Original (basic, used as inspiration) bamboo code by: Small Joker. Updates to the code: VoxeLibre Dev Team, Michieal.

License for code: GPLv3.
License for images / textures: CC-BY-SA except where noted.
Images Created by Nicu, except for:

* Inventory / wield image for Bamboo Stalk: created by RandomLegoBrick#8692 and is CC0.

Dependencies: mcl_core, mcl_sounds, mcl_tools

Optional Dependencies = mcl_flowerpots, mclx_stairs, mcl_doors, mcl_signs, mesecons_pressureplates, mcl_fences,
mesecons_button.
Note that "mcl_boats" may be used at a later date.

Special thanks to Nicu for help with a ton of things from testing, to encouragement, to graphic design and nodebox work.
Nicu - You Rock!

Small Joker's bamboo forum topic:
Forum topic: https://forum.luanti/viewtopic.php?id=8289

Scaffold inspiration: Cora, because she said that it couldn't be done.
