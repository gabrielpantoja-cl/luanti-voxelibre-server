Flowlib
================
Simple flow functions for use in Luanti mods by Qwertymine3

License of source code:
-----------------------
WTFPL
